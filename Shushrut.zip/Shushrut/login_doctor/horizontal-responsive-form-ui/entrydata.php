<!doctype html>
<?php $var=$_GET['del'];//echo ($var)?>
<html lang="en-US">
<head>
  <meta charset="utf-8">
  <meta http-equiv="Content-Type" content="text/html">
  <title>Online Prescription</title>
  <meta name="author" content="Jake Rocheleau">
  <link rel="shortcut icon" href="http://static.tmimgcdn.com/img/favicon.ico">
  <link rel="icon" href="http://static.tmimgcdn.com/img/favicon.ico">
  <link rel="stylesheet" type="text/css" media="all" href="css/styles.css">
  <link rel="stylesheet" type="text/css" media="all" href="css/switchery.min.css">
  <script type="text/javascript" src="js/switchery.min.js"></script>
</head>

<body>
  <div id="wrapper">
  <!?php $var=$_GET['del']?>
  <h1>Enter The Details</h1>
  
  <form class="return false" action="../../doc_pat_rec_add.php?" method ="POST">
  <div class="col-2">
    <label>
      Date of Consultation
      <input placeholder="Please enter your date of consultation" id="name" name="date" tabindex="1">
    </label>
  </div>
  <div class="col-2">
    <label>
      Illness
      <input placeholder="What illness does the patient suffers from?" id="company" name="ill" tabindex="2">
    </label>
  </div>
  
  <div class="col-3">
    <label>
      Medicine
      <input placeholder="What medicines do you prescribe?" id="phone" name="medi" tabindex="3">
    </label>
  </div>
  <div class="col-3">
    <label>
      Additional Information
      <input placeholder="Any additional information?" id="email" name="addinfo" tabindex="4">
    </label>
  </div>
  <div class="col-3">
    <label>
      Suggested pharmalogist
      <input placeholder="Who could be the best pharmalogist for him?" id="email" name="sugp" tabindex="4">
    </label>
  </div>
  
  <div class="col-4">
    <label>
      Suggested dermatologist 
      <input placeholder="Who could be the best dermatologist for him?" id="skills" name="sugd" tabindex="6">
    </label>
  </div>
  
  <div class="col-submit">
    <button class="submitbtn">Submit Form</button>
  </div>
  
  <input type='hidden' name='pati' value='<?php echo($var) ?>' >
  </form>
  </div>
<script type="text/javascript">
var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));

elems.forEach(function(html) {
  var switchery = new Switchery(html);
});
</script>
</body>
</html>