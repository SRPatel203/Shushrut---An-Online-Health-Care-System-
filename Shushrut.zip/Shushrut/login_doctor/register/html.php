<link rel="stylesheet" type="text/css" href="../css/style.css">
 <script type="text/javascript" src="java.js"></script>
<div class="main">
      <div class="one">
        <div class="register">
          <h3>Create your account</h3>
          <form id="reg-form">
            <div>
              <label for="name">Name</label>
              <input type="text" id="name" spellcheck="false" placeholder="Hashim Al-Qataberi"/>
            </div>
            <div>
              <label for="email">Email</label>
              <input type="text" id="email" spellcheck="false" placeholder="Anesi_90@hotmail.com"/>
            </div>
            <div>
              <label for="username">Username</label>
              <input type="text" id="username" spellcheck="false" placeholder="Hashim" />
            </div>
            <div>
              <label for="password">Password</label>
              <input type="password" id="password" />
            </div>
            <div>
              <label for="password-again">Password Again</label>
              <input type="password" id="password-again" />
            </div>
            
            


<div class="control-group">
  <label class="control-label" for="singlebutton"></label>
  <div class="controls">
    <button id="singlebutton" name="singlebutton" class="btn btn-success">Create acount</button>
  </div>
</div>


        </div>
      </div>
      
      
          </div>
        </div>
      </div>
    </div>