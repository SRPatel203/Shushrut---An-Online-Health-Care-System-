
<?php
session_start();
$con=@mysql_connect("localhost","root") or die ("couldn't connect");
@mysql_select_db("Shushrut") or die ("couldn't choose");

$query = mysql_query("INSERT INTO `patient_insurance`(`patient_id`, `Insurance`,`details`) VALUES ('$_SESSION[userName]','$_POST[det]','$_POST[name]');") or die(mysql_error());

echo "done";
?>