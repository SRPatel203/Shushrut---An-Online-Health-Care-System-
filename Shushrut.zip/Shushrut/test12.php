<head>
<link rel="stylesheet" type="text/css" href="patient/css/style.css">
<style>
.button {
  display: inline-block;
  border-radius: 4px;
  background-color: #f4511e;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 38px;
  padding: 20px;
  width: 200px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
}

.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button span:after {
  content: '<<<';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button:hover span {
  padding-right: 25px;
}

.button:hover span:after {
  opacity: 1;
  right: 0;
}
</style>

</head>
<body>
	<div id="page">
		<div id="header">
		<div>
				<p><tab1><a href="index.html"><img src="patient/images/logo2.jpg" alt="Logo" /></a></tab1></p>
			</div>
			<?php echo("OUR LOGO HERE!");?>
		</div>
<div id="body">
<ul>
<li>
<h1>


<?php
$con=@mysql_connect("localhost","root") or die ("couldn't connect");
@mysql_select_db("Shushrut") or die ("couldn't choose");

session_start();
if(isset($_GET['del'])){
     //$id = (int)$_GET['del'];
     //$removeQuery = "UPDATE Players Where id = $id";
     //header('Location: '.$_SERVER['REQUEST_URI']);
	//echo ($_GET['del']);
	//echo ($_GET['heal']);
	//echo ($_SESSION['userName']);
	echo("Tagging Successful");
	echo '<br/>';
	echo '<br/>';
	echo '<br/>';echo '<br/>';
	$query = mysql_query("INSERT INTO doc_pat_report(Doctor_id, Patient_id) VALUES ('$_GET[del]','$_SESSION[userName]');") or die(mysql_error());
	
	echo '<button class="button" style="vertical-align:middle"><span><a href="skype.php">Back to List</a> </span></button>';
 }
?>