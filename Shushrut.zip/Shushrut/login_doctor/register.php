<link rel="stylesheet" type="text/css" href="css/style.css">

<div class="login-page">
  <div class="form">
    <form class="register-form" method="POST" action="database_connect2.php">
      <input type="text" placeholder="name"/>
      <input type="password" placeholder="password"/>
      <input type="text" placeholder="email address"/>
      <button>create</button>
      <p class="message">Already registered? <a href="#">Sign In</a></p>
    </form>
      
      
    <form class="login-form" action ="../database_connect2.php" method = "POST">
      <input type="text" name="user" placeholder="username"/>
      <input type="password" name="pass" placeholder="password"/>
      <input type="text" name="name" />  
        
		
		
		
		Name <br><input type="text" name="name" size=100/><br>
	Reg no. <br><input type="text" name="reg"/><br>
	Phone no. <br><input type="text" name="phone"/><br>
	Email Id <br><input type="text" name="email" /><br>
	Branch <br><input type="text" name="branch"/><br>
	Year <br><input type="text" name="year"/><br>
	course <br><input type="text" name="course"/><br>
	Password <br><input type="text" name="password"/><br>

		
		
		
		
		
		
		
		
		
        <input id="button" type="submit" name="submit" value="Log-In">
        
      <button >login</button>
      <p class="message">Not registered? <a href="#">Create an account</a></p>
    </form>
  </div>
</div>