<!DOCTYPE HTML>
<head>

<style>
table, td, th {
    border: 1px solid #ddd;
    text-align: left;
}

table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    padding: 50px;
}
</style>

	<meta charset="UTF-8" />
	<title>Gardening Website Template</title>
	<link rel="stylesheet" type="text/css" href="doctor/css/style.css" />
	<!--[if IE 7]>
		<link rel="stylesheet" type="text/css" href="css/ie7.css" />
	<![endif]-->
	Patient Record
</head>
<body>
	<div id="page">
	Patient Record
		<div id="header">
		Patient Record
			<div>
				<p><tab1><a href="index.html"><img src="doctor/images/logo2.jpg" alt="Logo" /></a></tab1></p>
			</div>
			<h1>
			<div>
				<p><tab1>Patient Record</tab1></p>
			</div>
			</h1>
		</div>
		<div id="body">
			<ul>
				<li>
					<h1>

 
<?php $var=$_GET['del'] 
echo($var)?>
<!div id="Sign-In">
<!fieldset style="width:30%"><legend>Enter the details</legend>
<form method="POST" action="../../../doc_pat_rec_add.php">
Date of consultation <br><input type="text" name="date" size="39"><br>
Illness <br><input type="text" name="ill" size="39"><br>
Medicine <br><input type="text" name="medi" size="39"><br>

Additional information <br><textarea rows="5" cols="41" name="addinfo"></textarea><br>
Suggested pharmalogist <br><textarea rows="5" cols="41" name="sugp"></textarea><br>
Suggested dermatologist <br><textarea rows="5" cols="41" name="sugd"></textarea><br>

<input type='hidden' name='pati' value='<?php echo($var) ?>' > 


<input id="button" type="submit" name="submit" value="Add">
</form>
</fieldset>
</div>
<!iframe src="https://appear.in/your-room-name" width=700" height="600" frameborder="0"></iframe>
</body>
</html> 

