<!//---------------------------------------------Not my property-----------------------------------------------------//>
<!This monster is for login page! The data from the login page is sent here for verification!>
<!The dastabase used are:patient_entry,  and a few hyperlinks from here and there>
<!No need to look into php part,and BTW,most of it is copied too!>
<!The code just below is for the lists displayed!>
<!you might want to tweak there a bit!>
<!CSS file:link.css>
<!This file is for doctor database too!>
<! And here we go!>


<link rel="stylesheet" type="text/css" href="style6s.css">
<link href="style 8.css" rel="stylesheet" type="text/css" />
<link href="style 7.css" rel="stylesheet" type="text/css" />

<div id="wrapper">
<div id="header">
<div id="menu">
<ul>
  <li>
    <p><a href="patient_record.php">Medical record mmmmm</a></p>
    <span class="entypo-home"></span>
  </li>
  <li>
    <p><a href="link.css">Your awesome profile</a></p>
    <span class="entypo-user"></span>
  </li>
  <li>
    <p><a href="skype.php">Doctors</a></p>
    <span class="entypo-chat"></span>
  </li>
  
  <li>
    <p><a href="viewinsur.php">Insurances</a></p>
    <span class="entypo-chat"></span>
  </li>
  
  <li>
    <p><a href="https://news.google.com/news/section?cf=all&ned=us&q=health">Google Health News</a></p>
    <span class="entypo-rocket"></span>
  </li>
  <li>
    <p><a href="http://androctor.com/">Health Predictor</a></p>
    <span class="entypo-logout"></span>
  </li>
  
  <li>
    <p><a href="#">BMI</a></p>
    <span class="entypo-logout"></span>
  </li>
  
  
  <li>
    <p><a href="#">Research Papers</a></p>
    <span class="entypo-logout"></span>
  </li>
</ul> 

//---------------------------------------------Not my property-----------------------------------------------------//














<head>

<a href="1s.php">Visit our HTML tutorial</a>
</head>
<body>
<?php
$con=@mysql_connect("localhost","root") or die ("couldn't connect");
@mysql_select_db("Shushrut") or die ("couldn't choose");
/*
$ID = $_POST['user'];
$Password = $_POST['pass'];
*/
function test($name)
{
	echo GetType($name);
	echo $name['userName'];
	
}

function SignIn()
{
session_start();   //starting the session for user profile page
echo("asdfasdfasdfa");
    if(!empty($_POST['user']))   //checking the 'user' name which is from Sign-In.html, is it empty or have some text
{
	//include "testp.php";
	echo("in here");
	$query = mysql_query("SELECT *  FROM patient_entry where Email_Id = '$_POST[user]' AND Password = '$_POST[pass]'+'\r'") or die(mysql_error());
	//echo("in here");
	$row = mysql_fetch_array($query) or die(mysql_error());
	echo($row['Email_Id']);
	if(!empty($row))
	{
		$_SESSION['userName'] = $row['Patient_Id'];
		
		echo "SUCCESSFULLY LOGIN TO USER PROFILE PAGE...";
		//echo "Hello ";
		test($_SESSION);
		//llo("heee");
		$str=$_SESSION;
		echo '<p class="stylesheet">'."hello".'</p>';
        //echo '<p class="style">'.$ip['countryName'].'</p>';
		//echo ($row['Name']);

	}
	else
	{
		echo "SORRY... YOU ENTERD WRONG ID AND PASSWORD... PLEASE RETRY...";
	}
}
}
if(isset($_POST['submit']))
{
	SignIn();
}

?>
<input type="button" value="Put Your Text Here" onclick="test("gee")" />
</body>