
<head>
<link rel="stylesheet" type="text/css" href="patient/css/style.css">
<style>
table, td, th {
    border: 1px solid black;
    text-align: left;
}

table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    padding: 15px;
}
</style>
<script>
</script>



</head>

<body>
	<div id="page">
		<div id="header">
		<div>
				<p><tab1><a href="index.html"><img src="patient/images/logo2.jpg" alt="Logo" /></a></tab1></p>
				<P><tab1><h1>DOCTORS</h1></tab1></P>
			</div>
				
		
		</div>


<?php


session_start();
$con=@mysql_connect("localhost","root") or die ("couldn't connect");
@mysql_select_db("Shushrut") or die ("couldn't choose");



 //$query = mysql_query("INSERT INTO doc_pat_report(Doctor_id, Patient_id) VALUES ('sert','1234');") or die(mysql_error());
 
$query = mysql_query("SELECT A.Doctor_id, B.Name, C.time_slot,C.ends,A.id FROM doctor_skype A , doctor_login B, doc_avail C WHERE A.Doctor_id= B.Doctor_id and A.Doctor_id=C.Doctor_id;") or die(mysql_error());
//$row = mysql_fetch_array($query) or die(mysql_error());
	
//echo "hello:";
$str1="this";
//print_r($_SESSION["userName"]);
//echo($str3);
//echo '<button type="button" action=fun()>Click Me!</button>';
echo '<table cellpadding="0" cellspacing="0" class="db-table">';
echo '<tr><th>Name</th><th>Free from</th><th>Till</th><th>To call</th><th>To chat</th>';
echo '<ul>';
while( $row=mysql_fetch_array($query))
{
			//echo ($row[0]);
			echo '<tr>';
			for($j=1;$j<4;$j++) 
			{
				
			echo '<td>',$row[$j],'</td>';
			}
			$str4="skype:".$row[4]."?call";
			$str5="skype:".$row[4]."?chat";
			$str6="nofollow";
			//$link_address=
			//echo '<td>' "<a href='".$str4."' rel='"."nofollow"."'>Link</a>" '</td>';
			//echo '<td>' '<a href="$str4" >Link</a>' '</td>';
			echo '<td>' ,'<a href="'.$str4.'">CALL ME PLEASE</a>' , '</td>';
			echo '<td>' ,'<a href="'.$str5.'">LETS CHAT</a>' , '</td>';
			//echo '<td>' ,'<a href="">CHAT WITH ME PLEASE</a>' , '</td>';
			//echo '<td>' , '<button type="button" action=fun()>Click Me!</button>' ,'</td>';
			//echo "<td><button onclick=\"fun()\">Kill</button></td>";
			//echo "<td><button onclick=\"myFunction('" . $row[0] . "')\">Kill</button></td>";
            //echo "<td><button onclick=\"myfunction('" . $row[0] . "')\">Kill</button></td>";
			//echo "<td><a href='test12.php?del=". $row[0]."'> Tag </a></td>"; 
	 
	 
	 
	 //echo  "<a href='test12.php?del=".$row['id']."' class='btn btn btn-danger' aria-label='Left Align' name='remove' value='remove'>Remove</button></td>";    
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
    
echo '</tr>';
			//echo "*";
}
		echo '</table><br />';

?>

</div>
</div>

</body>
<script>

<?php
function myFunction($p1)
{
 //$query = mysql_query("INSERT INTO doc_pat_report(Doctor_id, Patient_id) VALUES ('sert','1234');") or die(mysql_error());
 //echo (p1);
  
}
?>
</script>


















 


<!--
<script type="text/javascript" src="https://secure.skypeassets.com/i/scom/js/skype-uri.js"></script>

<div id="SkypeButton_Call_abhilash.mishra9796_1">
 <script type="text/javascript">
 //window.alert(<?php echo($str1) ?>);
 Skype.ui({
 "name": "dropdown",
 "element": "SkypeButton_Call_abhilash.mishra9796_1",
 "participants": ["abhilash.mishra9796"]
 });
 </script> -->
</div>
