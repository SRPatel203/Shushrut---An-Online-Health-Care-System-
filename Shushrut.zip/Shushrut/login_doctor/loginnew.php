<link rel="stylesheet" type="text/css" href="css/style.css">

<div class="login-page">
  <div class="form">
    <form class="register-form" method="POST" action="database_connect2.php">
      <input type="text" placeholder="name"/>
      <input type="password" placeholder="password"/>
      <input type="text" placeholder="email address"/>
      <button>create</button>
      <p class="message">Already registered? <a href="#">Sign In</a></p>
    </form>
      
      
    <form class="login-form" action ="files/database_connect2.php">
      <input type="text" name="user" placeholder="username"/>
      <input type="password" name="pass" placeholder="password"/>
        
        
        <input id="button" type="submit" name="submit" value="Log-In">
        
      <button >login</button>
      <p class="message">Not registered? <a href="#">Create an account</a></p>
    </form>
  </div>
</div>