<link rel="stylesheet" type="text/css" href="style.css">

<div class="login-page">
  <div class="form">
    <form class="register-form" method="POST" action="database_connect2.php">
      <input type="text" placeholder="name"/>
      <input type="password" placeholder="password"/>
      <input type="text" placeholder="email address"/>
      <button>create</button>
      <p class="message">Already registered? <a href="#">Sign In</a></p>
    </form>
</div>