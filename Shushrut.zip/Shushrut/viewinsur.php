<head>
<link rel="stylesheet" type="text/css" href="patient/css/style.css" />
<style>
table, td, th {
    border: 1px solid black;
    text-align: left;
}

table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    padding: 15px;
}
</style>
</head>
<body>
	<div id="page">
		<div id="header">
		<div>
				<p><tab1><a href="index.html"><img src="patient/images/logo2.jpg" alt="Logo" /></a></tab1></p>
				<p><h1><tab1>INSURANCE DETAILS</h1></tab1></p>
			</div>
			<!?php echo("OUR LOGO HERE!");?>
		</div>
<?php
session_start();
$con=@mysql_connect("localhost","root") or die ("couldn't connect");
@mysql_select_db("Shushrut") or die ("couldn't choose");

$query = mysql_query("SELECT  `Insurance`,`details` FROM `patient_insurance` WHERE `patient_id`='$_SESSION[userName]';") or die(mysql_error());
echo '<table cellpadding="0" cellspacing="0" class="db-table">';
echo '<tr>';
echo '<th><h3>Insurances</h3></th><th><h3>Insurance Details</h3></th>';
//echo '<ul>';
echo '<tr>';
while( $row=mysql_fetch_array($query))
{
	echo '<td>',$row[0],'</td>';
	//echo();
	
	echo '<td>',$row[1],'</td>';
	echo '<tr>';
	//echo();
}
echo '</tr>';
echo '</table><br />';
?>

<br><a href='/login2/Insurance'> Add new insurance details </a></br>
