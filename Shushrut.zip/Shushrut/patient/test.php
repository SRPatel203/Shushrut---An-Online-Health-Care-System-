<html>
<head>

<style type="text/css">
a:link    {
  /* Applies to all unvisited links */
  text-decoration:  none;
  font-weight:      bold;
  background-color: none;
  text-color:#FFFFFF;
  } 
</style>



asdfasfasdf
	<meta charset="UTF-8" />
	<title>Health Care System,Shushrut</title>
	<link rel="stylesheet" type="text/css" href="css/style.css" />
	<!--[if IE 7]>
		<link rel="stylesheet" type="text/css" href="css/ie7.css" />
	<![endif]-->
	<style type="text/css">
            tab1 { padding-left: 40em; }
	</style>
	<style>
.button {
  display: inline-block;
  border-radius: 4px;
  background-color: #f4511e;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 28px;
  padding: 20px;
  width: 200px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
  
}

.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button:hover span {
  padding-right: 25px;
}

.button:hover span:after {
  opacity: 1;
  right: 0;
}
</style>

</head>
<body>
	<div id="page">
		<div id="header">
		<div>
				<p><a href="index.html"><img src="images/logo2.jpg" alt="Logo" /></a></tab1></p>
			</div>
			<!?php echo("OUR LOGO HERE!");?>
		</div>


<div id="body" align=CENTER>
<!ul>
<!li>
<h1>
						
						<!br/>
						<!br/>
						<br/>
						<br/>
						
						<ul>
						
						


<?php
//echo("Hello4");
$con=@mysql_connect("localhost","root") or die ("couldn't connect");
@mysql_select_db("Shushrut") or die ("couldn't choose");
/*
$ID = $_POST['user'];
$Password = $_POST['pass'];
*/
function test($name)
{
		//echo GetType($name);
	//	echo $name['userName'];
	
}

function SignIn()
{
	session_start(); 
	//echo("in hereeeee!");
		//starting the session for user profile page
	if(!empty($_POST['user']))   //checking the 'user' name which is from Sign-In.html, is it empty or have some text
	{
		//include "testp.php";
		//echo("in here");
		$query = mysql_query("SELECT *  FROM patient_entry where Email_Id = '$_POST[user]' AND Password = '$_POST[pass]'") or die(mysql_error());
		//echo("in here");
		$row = mysql_fetch_array($query) or die(mysql_error());
		
		//echo("Hello "+$row['Email_Id']);
		if(!empty($row))
		{
			$_SESSION['userName'] = $row['Patient_Id'];
			
			echo ('<p>Hello</p>' );
			echo($row['Name']);
			
			//echo "SUCCESSFULLY LOGIN TO USER PROFILE PAGE...";
			//echo "Hello "+ $_SESSION['userName'];
			test($_SESSION);
			//llo("heee");
			$str=$_SESSION;
			//echo '<p class="stylesheet">'."hello".'</p>';
			//echo '<p class="style">'.$ip['countryName'].'</p>';
			//echo ($row['Name']);
			echo('<br/>');
			echo('<br/>');
			echo('<br/>');
			//echo '<button class="button" style="vertical-align:middle"><a href="index.html">Continue</a> </span></button>';
			//echo('<button><a href="index.html">Continue</a></button>');
			echo('<button class="button" style="vertical-align:middle"><span><a href="index.html">Continue </a></span></button>');
		}
		else
		{
			echo "SOOOOORY";
			echo "SORRY... YOU ENTERD WRONG ID AND PASSWORD... PLEASE RETRY...";
		}
	}
}


if(isset($_POST['user'])&&($_POST['pass']))
{
	//echo("Hello2");
	SignIn();
	//echo "hello";
}

?>


</li>
</ul>
</div>
</body>
