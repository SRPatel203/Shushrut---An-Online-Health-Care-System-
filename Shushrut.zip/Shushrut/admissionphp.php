<link rel="stylesheet" type="text/css" media="all" href="css/styles.css">
<link rel="stylesheet" type="text/css" media="all" href="css/switchery.min.css">
<link rel="shortcut icon" href="http://static.tmimgcdn.com/img/favicon.ico">
<link rel="icon" href="http://static.tmimgcdn.com/img/favicon.ico">

<div id="wrapper">
<h1>
<?php
$con=@mysql_connect("localhost","root") or die ("couldn't connect");
@mysql_select_db("Shushrut") or die ("couldn't choose");


    //echo ($_POST['ill']);
    $query2= mysql_query("SELECT count(Email_Id) FROM patient_entry");
	$row = mysql_fetch_array($query2) or die(mysql_error());
	$t=(int)$row[0];
	$t=$t+1;
	//echo($t+1);
	$t=$t+1000;
	
	//$ttt='p'+(string)$tt;
	//echo($_POST['name']+$_POST['reg']+$_POST['phone']+$_POST['email']+$_POST['branch']+$_POST['year']+$_POST['course']+$_POST['password']);
	$query = mysql_query("INSERT INTO patient_entry(SI_No,Name, Reg_No, Phone_No, Email_Id, Branch, Year, Course,Patient_Id,Password) VALUES ('$t','$_POST[name]','$_POST[reg]','$_POST[phone]','$_POST[email]','$_POST[branch]','$_POST[year]','$_POST[course]','$t','$_POST[password]')") or die(mysql_error());
	echo ("done! You are now a part of the Shushrut Health Care");
	//echo("in here");
	//$row = mysql_fetch_array($query) or die(mysql_error());
	//echo($row['Email_Id']);
?>
</h1>
</div>