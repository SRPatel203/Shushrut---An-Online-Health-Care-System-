
<head>
<link rel="stylesheet" type="text/css" href="patient/css/style.css">


<style>
table, td, th {
    border: 1px solid black;
    text-align: left;
}

table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    padding: 15px;
}
</style>
</head>
<body>
	<div id="page">
		<div id="header">
		<div>
				<p><tab1><a href="patient/index.html"><img src="patient/images/logo2.jpg" alt="Logo" /></a></tab1></p>
				<p><tab1><h1>PATIENT RECORDS</h1></tab1></p>
			</div>
			<!?php echo("OUR LOGO HERE!");?>
		</div>



<?php
session_start();
$con=@mysql_connect("localhost","root") or die ("couldn't connect");
@mysql_select_db("Shushrut") or die ("couldn't choose");
?>
<div id="contain1">

<?php

// Echo session variables that were set on previous page
//echo "Favorite color is " . $_SESSION["Email_Id"] . ".<br>";
//echo "Favorite animal is " . $_SESSION["favanimal"] . ".";
//$query = mysql_query("SELECT * FROM `patient_record` WHERE patient_id='$_SESSION['userName']'") or die(mysql_error());
$query = mysql_query("SELECT * FROM `patient_record` WHERE patient_id= '" .
mysql_real_escape_string($_SESSION['userName']). "'");
//echo ($_SESSION['userName']);
//echo '<h3>',$table,'</h3>';
echo '<table cellpadding="0" cellspacing="0" class="db-table">';
echo '<tr><th>Illness</th><th>MedicineS</th><th>Doctor_id</th><th>Date of consultancy</th>';
echo '<tr>';
while( $row=mysql_fetch_array($query))
{
			//echo ($row[0]);
			
			for($j=1;$j<5;$j++) 
			{
				
			echo '<td>',$row[$j],'</td>';
			//echo "<td><a href='test12.php?del=". $row[0]."'> febe </a></td>";
			}
			
			echo '</tr>';
			//echo "*";
}
echo '</tr>';
		echo '</table><br />';

?>


<!DOCTYPE html>
<html>
<head>

</head>
<body>

hope this works:<tr><td> <input type="hidden" name="type" value="<?= $var ?>" ></td></tr>
 This is the new section
</div>
</body>
</html>