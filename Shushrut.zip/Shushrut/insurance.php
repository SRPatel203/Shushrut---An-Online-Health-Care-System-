<!DOCTYPE HTML>

<html>
<head>
<title>Sign-In</title>
<link rel="stylesheet" type="text/css" href="patient/css/style.css">
<style>
.button1 {
    box-shadow: 0 16px 32px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19),width=100;
}
.button2:hover {
    box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19);
}
</style>
</head>
<body id="body-color">
<?php //$var=$_GET['del'] ?>
<div id="Sign-In">
<fieldset style="width:30%"><legend>Enter the details</legend>
<ul>
<form method="POST" action="insurancephp.php?">


Insurance: <br><textarea rows="5" cols="41" name="ins"></textarea><br>

Insurance Details: <br><textarea rows="5" cols="41" name="det1"></textarea><br>

 


<input id="button" class="button1" type="submit" name="submit" value="Add">
</form>
</fieldset>
</div>
<!iframe src="https://appear.in/your-room-name" width=700" height="600" frameborder="0"></iframe>
</body>
</html> 

