<head>

<style>
table, td, th {
    border: 1px solid #ddd;
    text-align: left;
}

table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    padding: 15px;
}
</style>

	<meta charset="UTF-8" />
	<title>Patients tagged</title>
	<link rel="stylesheet" type="text/css" href="doctor/css/style.css" />
	<!--[if IE 7]>
		<link rel="stylesheet" type="text/css" href="css/ie7.css" />
	<![endif]-->
</head>
<body>
	<div id="page">
		<div id="header">
			<div>
				<p><tab1><a href="index.html"><img src="doctor/images/logo2.jpg" alt="Logo" /></a></tab1></p>
				<p><tab1><h1>PATIENTS WHO HAVE TAGGED</h1></tab1></p>
			</div>
			
		</div>
		<div id="body">
			<ul>
				<li>
					<h1>


<?php function fun()
{
	
	echo "hello**********************************************************************";
}
session_start();
$con=@mysql_connect("localhost","root") or die ("couldn't connect");
@mysql_select_db("Shushrut") or die ("couldn't choose");
$query = mysql_query("select A.Patient_Id,B.Name,B.Reg_No,B.Phone_No,B.Email_Id from doc_pat_report A, patient_entry B where A.`Patient_Id`=B.`Patient_Id` and Doctor_id='$_SESSION[userName]' ORDER BY `Branch` DESC") or die(mysql_error());


//echo '<button type="button" action=fun()>Click Me!</button>' ;
echo '<table cellpadding="0" cellspacing="0" class="db-table">';
echo '<tr><th>Name</th><th>Registration Number from</th><th>Phone Number</th><th>Email Id</th><th>Medical history</th>';

while( $row=mysql_fetch_array($query))
{
				echo '<tr>';
				echo '<td>',$row[1],'</td>';
				echo '<td>',$row[2],'</td>';
				echo '<td>',$row[3],'</td>';
				echo '<td>',$row[4],'</td>';
				echo "<td><a href='test14.php?del=". $row[0]."'> medical history </a></td>"; 
				echo '</tr>';
			
}			
			
echo '</table><br />';		
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			/*
			echo '<tr>';
			for($j=1;$j<4;$j++) 
			{
				
			echo '<td>',$row[$j],'</td>';
			}
			$str4="skype:".$row[4]."?call";
			$str5="skype:".$row[4]."?chat";
			$str6="nofollow";
			//$link_address=
			//echo '<td>' "<a href='".$str4."' rel='"."nofollow"."'>Link</a>" '</td>';
			//echo '<td>' '<a href="$str4" >Link</a>' '</td>';
			echo '<td>' ,'<a href="'.$str4.'">CALL ME PLEASE</a>' , '</td>';
			echo '<td>' ,'<a href="'.$str5.'">CHAT WITH ME PLEASE</a>' , '</td>';
			echo '<td>' ,'<a href="">CHAT WITH ME PLEASE</a>' , '</td>';
			//echo '<td>' , '<button type="button" action=fun()>Click Me!</button>' ,'</td>';
			//echo "<td><button onclick=\"fun()\">Kill</button></td>";
			echo "<td><button onclick=\"myFunction('" . $row[0] . "')\">Kill</button></td>";
            //echo "<td><button onclick=\"myfunction('" . $row[0] . "')\">Kill</button></td>";
			echo "<td><a href='test12.php?del=". $row[0]."'> febe </a></td>"; 
	 
	 //echo  "<a href='test12.php?del=".$row['id']."' class='btn btn btn-danger' aria-label='Left Align' name='remove' value='remove'>Remove</button></td>";    
	     
echo '</tr>';
			//echo "*";
}
		echo '</table><br />';
*/

?>